#include "card.h"
#include "deck.h"

Deck()
{
	
}

void shuffle()
{

}

Card dealCard()
{
	return myCards[myIndex];
}
