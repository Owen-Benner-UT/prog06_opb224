#include "player.h"
#include "card.h"

Player::Player()
{

}

void Player::addCard(Card c)
{
	//cout << "addCard\n";
}

void Player::bookCards(Card c1, Card c2)
{

}

string Player::showHand() const
{
	return "";
}
