#include "card.h"
#include "player.h"

Player()
{

}

void addCard(Card c)
{

}

void bookCards(Card c1, Card c2)
{

}
